<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['system_name']	= 'Fahim Seminar';
$config['system_email']	= '';
$config['email_password'] = '';

$config['dev_mode'] = 'off';

