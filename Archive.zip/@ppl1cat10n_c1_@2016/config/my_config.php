<?php
	date_default_timezone_set('Asia/Kuala_Lumpur');
	
	//$config['column_user_level'] = "USER LEVEL X";
	
	$config['credits_limit'] = 19;
?>