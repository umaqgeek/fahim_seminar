
<!-- Footer -->
<section id="footer" style="margin-top: 30%;">
    <div class="container">
        <ul class="copyright">
            <li>&copy; Nine 40 Trainer. All rights reserved.</li>
        </ul>
    </div>
</section>

</div>

<!-- Scripts -->
<script src="<?= base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.scrollzer.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.scrolly.min.js"></script>
<script src="<?= base_url(); ?>assets/js/skel.min.js"></script>
<script src="<?= base_url(); ?>assets/js/util.js"></script>
<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
<script src="<?= base_url(); ?>assets/js/main.js"></script>

</body>
</html>