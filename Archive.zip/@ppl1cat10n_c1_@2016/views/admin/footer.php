

<!-- Footer -->
<section id="footer" style="margin-top: 30%;">
    <div class="container">
        <ul class="copyright">
            <li>&copy; Nine 40 Trainer. All rights reserved.</li>
        </ul>
    </div>
</section>

</div>

</body>
</html>