<!-- Main -->
<div id="main">

    <!-- Two -->
    <section id="two">
        <div class="container">
            <h3>Things I Can Do</h3>
            <p>Integer eu ante ornare amet commetus vestibulum blandit integer in curae ac faucibus integer non. Adipiscing cubilia elementum integer lorem ipsum dolor sit amet.</p>
            <ul class="feature-icons">
                <li class="fa-code">Write all the code</li>
                <li class="fa-cubes">Stack small boxes</li>
                <li class="fa-book">Read books and stuff</li>
                <li class="fa-coffee">Drink much coffee</li>
                <li class="fa-bolt">Lightning bolt</li>
                <li class="fa-users">Shadow clone technique</li>
            </ul>
        </div>
    </section>
    
</div>